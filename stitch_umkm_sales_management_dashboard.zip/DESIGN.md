---
name: Kopi Senja POS & UMKM
colors:
  surface: '#fbf8ff'
  surface-dim: '#dad9e6'
  surface-bright: '#fbf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f2ff'
  surface-container: '#eeecfb'
  surface-container-high: '#e8e7f5'
  surface-container-highest: '#e2e1ef'
  on-surface: '#1a1b25'
  on-surface-variant: '#494455'
  inverse-surface: '#2f303a'
  inverse-on-surface: '#f1effd'
  outline: '#7a7486'
  outline-variant: '#cbc3d7'
  surface-tint: '#6b39de'
  primary: '#5c24cf'
  on-primary: '#ffffff'
  primary-container: '#7545e8'
  on-primary-container: '#eee4ff'
  inverse-primary: '#cfbdff'
  secondary: '#0054ca'
  on-secondary: '#ffffff'
  secondary-container: '#2b6eeb'
  on-secondary-container: '#fefcff'
  tertiary: '#005c3e'
  on-tertiary: '#ffffff'
  tertiary-container: '#007751'
  on-tertiary-container: '#83ffc6'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e8ddff'
  primary-fixed-dim: '#cfbdff'
  on-primary-fixed: '#22005d'
  on-primary-fixed-variant: '#5210c5'
  secondary-fixed: '#dae2ff'
  secondary-fixed-dim: '#b1c5ff'
  on-secondary-fixed: '#001946'
  on-secondary-fixed-variant: '#00419f'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#fbf8ff'
  on-background: '#1a1b25'
  surface-variant: '#e2e1ef'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 12px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-tablet: 1.25rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system is crafted for high-frequency point-of-sale operations, inventory management, and financial record-keeping for independent food & beverage businesses and modern micro/SME merchants (UMKM). 

The emotional signature balances tactile, physical calmness with modern operational precision. Rather than flat, sterile corporate layouts, the interface utilizes modern soft neumorphism: elements appear seamlessly embossed or carved directly into an organic, soft alabaster surface. This tactile depth provides tactile satisfaction during rapid counter transactions while reducing visual fatigue under harsh indoor café lighting.

### Visual Aesthetic
- **Soft Neumorphism:** Organic extrusions, soft dual-light specular highlights (upper left: `#FFFFFF`) paired with cool tinted lavender drop shadows (lower right: `rgba(163, 177, 198, 0.28)`).
- **Vibrant Accent Energy:** High-contrast purple-to-electric-blue gradients on interactive targets to draw focus immediately to transaction CTAs, checkout buttons, and key sales figures.
- **Clarity & Hygiene:** Generous internal paddings, rounded organic containers, and uncompromised WCAG AA contrast for text, numbers, and status indicators.

## Colors

The color palette centers on clean, illuminated tones and functional accents:

- **Primary Canvas (`#F7F7FC`):** The master canvas tone. Neumorphic lighting calculations depend strictly on surfaces sharing this precise base luminance.
- **Secondary Canvas / Ambient Tint (`#F0EFFA`):** A tranquil lavender-tinted neutral applied to peripheral panels, secondary order lists, and receipt drawers.
- **Brand Primary Accent (`#7545E8`):** A saturated violet used for high-priority actions, active navigation states, and primary summary metrics.
- **Secondary Accent (`#3978F6`):** Electric blue paired in 135° gradients (`linear-gradient(135deg, #7545E8 0%, #3978F6 100%)`) with the primary violet for key checkout buttons, badge accents, and interactive toggles.
- **Success / Revenue (`#10B981`):** An emerald green reserved for completed cash/QRIS payments, revenue growth, and in-stock inventory items.
- **Warning / Alert (`#F59E0B` / `#EF4444`):** Warm amber for pending orders and crimson red for voids, refunds, or low-stock warnings.
- **Typography & Details:** Primary text is grounded in deep obsidian charcoal (`#20212B`), while secondary metadata and placeholder text rest in muted slate-lavender (`#9293A5`).

## Typography

The typography uses Plus Jakarta Sans across all display, body, and interface tokens. Its geometric balance, wide apertures, and clean terminal strokes ensure zero ambiguity when reading product SKU codes, rupiah currency amounts, and inventory quantities on mobile tablets or POS counter terminals.

- **Financial & Numeric Displays:** All financial totals and transactional summaries use tabular figures (`font-variant-numeric: tabular-nums`) with `font-weight: 700` to prevent horizontal jitter during live cart updates.
- **Hierarchy:** `headline-xl` is strictly reserved for primary register balances and daily shift turnover. `headline-lg` and `headline-md` designate product category titles and modal titles. `body-md` handles standard POS line items, while `label-md` and `label-sm` support status tags and timestamps.

## Layout & Spacing

The layout is structured around an 8-point base spatial rhythm adapted to touch-heavy POS workflow and responsive web management:

- **POS Mobile & Handheld Terminal:** Single-column stacked order stream with a sticky bottom neumorphic summary card. Margins default to `margin` (1rem / 16px).
- **Tablet POS Landscape (Standard Counter Device):** Dual-pane split: 60% catalog grid on the left, 40% cart bill ledger on the right. Gutters between item cards scale to `gutter-tablet` (1.25rem / 20px).
- **Desktop Analytics & Management:** 12-column layout with fixed neumorphic sidebar navigation (260px) and a fluid analytics canvas with `margin-desktop` (2rem / 32px).
- **Touch Ergonomics:** All clickable grid items and cart adjustment buttons have minimum physical hit targets of 48px × 48px to accommodate rapid finger tapping.

## Elevation & Depth

Visual depth is achieved through bi-directional directional lighting, assuming an upper-left light source at 135 degrees. Surfaces match the parent canvas tone (`#F7F7FC` or `#F0EFFA`) without solid borders.

### Neumorphic Elevation Levels

1. **Extruded Surface (Cards, Modals, Category Chips):**
   - Soft outer elevation: `box-shadow: 10px 10px 20px rgba(163, 177, 198, 0.28), -10px -10px 20px rgba(255, 255, 255, 0.95);`
   - Floating micro-elements (FABs, Icon Triggers): `box-shadow: 6px 6px 14px rgba(163, 177, 198, 0.24), -6px -6px 14px rgba(255, 255, 255, 0.9);`

2. **Recessed / Inset Surface (Input Fields, Search Bars, Depressed State):**
   - Inset shadows simulate a gentle stamped indentation into the surface: `box-shadow: inset 4px 4px 8px rgba(163, 177, 198, 0.25), inset -4px -4px 8px rgba(255, 255, 255, 0.9);`

3. **Active Accent Glow (Primary Buttons):**
   - High-contrast gradient elements use saturated colored drop shadows rather than neutral ones: `box-shadow: 0 10px 24px rgba(117, 69, 232, 0.35), 0 2px 6px rgba(57, 120, 246, 0.2);`

## Shapes

The design system uses soft, pill-inspired curvilinear shapes to reinforce the clay-like, extruded neumorphic feel:

- **Standard Containers & Cards:** Rounded with 20px to 24px radii (`rounded-2xl` / `rounded-3xl`) ensuring shadow blur disperses smoothly along corners without clipping artifacts.
- **Buttons, Action Pills & Status Badges:** Fully rounded capsule/pill contours (`border-radius: 9999px`).
- **Input Fields:** Semi-pill rounded curves (`border-radius: 16px` to `20px`) matching the natural finger groove.
- **Strict Prohibition:** Hard sharp corners (0px) are prohibited, as neumorphic highlights cannot render soft continuous bevels on 90-degree apexes.

## Components

### Buttons
- **Primary Action (Pay / Charge / Submit):** Solid gradient fill from `#7545E8` to `#3978F6` at 135°, white bold text (`#FFFFFF`), fully pill-shaped (`rounded-full`), padded with `1rem 2rem`, layered with `0 10px 20px rgba(117, 69, 232, 0.35)` shadow. On active press: scaled to `0.98` with reduced shadow.
- **Neumorphic Secondary Button:** Same base background as the canvas (`#F7F7FC`), text in `#20212B`, dual outer shadow (`6px 6px 12px rgba(163,177,198,0.25), -6px -6px 12px #FFFFFF`). When clicked/active, toggles instantly to the inset shadow pattern.

### Input Fields
- **Search & Cash Inputs:** Recessed neumorphic background with `inset 3px 3px 6px rgba(163,177,198,0.2), inset -3px -3px 6px rgba(255,255,255,0.85)`. Borderless. Left-aligned subtle icon in `#9293A5`. Active focus state introduces a subtle 1px inner ring tinted `#7545E8` at 40% opacity.

### POS Item & Catalog Cards
- **Product Card:** Extruded surface with `10px 10px 20px rgba(163, 177, 198, 0.22), -10px -10px 20px #FFFFFF`. Top image container features rounded-xl styling with an inner subtle inset border. Price tag rendered in bold `#7545E8`. When selected into the cart, the card renders a vibrant 2px gradient outline and an ambient violet highlight.

### Chips & Category Tabs
- **Inactive Chip:** Extruded neumorphic capsule, text `#9293A5`, dual drop shadow.
- **Active Chip:** Recessed inset shadow, text `#7545E8` with `font-weight: 700`, with a small vibrant violet status dot.

### Cart & Receipt Drawer
- **Order Panel:** Background in `#F0EFFA` to provide natural structural demarcation from the catalog grid without harsh borders.
- **Line Items:** Separated with generous whitespace (`space-sm`), quantity counters styled as small circular neumorphic stepper buttons (`+` and `-`) with tactile click feedback.
- **Total Amount Pill:** Recessed summary bar displaying final total with bold 24px `headline-lg` tabular numerals.